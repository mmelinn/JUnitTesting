package com.melin.junit;

// mengimpor metode assertEquals dari JUnit,
// yang digunakan untuk membandingkan hasil yang diharapkan dengan hasil aktual.
import static org.junit.Assert.assertEquals;

// mengimpor anotasi @Test dari JUnit,
// yang digunakan untuk menandai metode sebagai metode uji.
import org.junit.Test;

public class LuasLingkaranTest {

    // membuat objek LuasLingkaran yang akan digunakan dalam pengujian.
    private LuasLingkaran luasLingkaran = new LuasLingkaran();

        // menandai metode testHitungLuas sebagai metode uji.
        @Test

        // metode pengujian yang akan memanggil hitungLuas dan membandingkan hasilnya.
        public void testHitungLuas() {

            // memanggil metode hitungLuas dari objek luasLingkaran dengan jari-jari lingkaran sebesar 5
            // dan menyimpan hasilnya dalam variabel result.
            Integer result = luasLingkaran.hitungLuas(5);

            // membandingkan hasil yang diharapkan (78) dengan hasil yang sebenarnya (result).
            // jika hasilnya tidak sesuai, tes unit akan gagal.
            assertEquals(Integer.valueOf(79), result);

        }
}