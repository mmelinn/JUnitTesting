package com.melin.junit;

// membuat sebuah kelas dengan nama LuasLingkaran.
public class LuasLingkaran {

    // deklarasi metode hitungLuas dengan tipe pengembalian Integer
    // yang menerima satu parameter jariJari dengan tipe Integer
    public Integer hitungLuas(Integer jariJari) {

        // menghitung luas lingkaran dengan rumus matematika: π * jariJari^2.
        // hasil perhitungan disimpan dalam variabel luas dengan tipe Double.
        // Math.PI adalah konstanta yang merepresentasikan nilai π (pi).
        // Math.pow(jariJari, 2) menghitung jari-jari lingkaran yang dipangkatkan dengan 2 (untuk menghitung kuadratnya).
        Double luas = Math.PI * Math.pow(jariJari, 2);

        // mengonversi hasil perhitungan luas lingkaran dari tipe Double ke Integer.
        Integer luasLingkaran = (int) Math.round(luas);

        // mengembalikan hasil perhitungan luas lingkaran dalam bentuk Integer ke pemanggil metode
        return luasLingkaran;

    }
}